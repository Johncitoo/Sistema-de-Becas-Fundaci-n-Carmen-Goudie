export class CreateOnboardingDto {}
